
/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "main.h"
#include "stm32f4xx_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */


#define SYSTEM_CORE_CLOCK 80000000.0f  //(80MHz)
#define PI 3.1415926535
#define enchetillion 200

#define POT1 ADC_CHANNEL_1
#define POT2 ADC_CHANNEL_4


uint32_t sinus[enchetillion];
float frequence = 50.0f; // Initial frequency in Hz
int amplitude = 100;     // Initial amplitude (0 to 1)
volatile uint8_t boutonEtat =0;
volatile uint8_t controle =0;
char uart_rx_buffer[20];

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
TIM_HandleTypeDef htim2;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_tim2_up;



/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

void Error_Handler(void);
void UART(void);
void set_sine_wave(float freq, float amplitude);
uint16_t lecturePotetiometre(uint32_t channel);
void print(const char *format, ...);
void creation_du_table_sine(float amplitude,uint32_t arr);
long map(long x, long entre_minimal, long entre_maximal, long sortie_minimal, long sortie_maximal);
void LireAmpFreq(void);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */




//==========================================================
//   Fonction pour envoyer un message via UART
//==========================================================
void print(const char *format, ...) {
    char buffer[100];  // Buffer pour stocker le message
    va_list args;
    va_start(args, format);
    vsprintf(buffer, format, args); // Formatte le texte
    va_end(args);
    HAL_UART_Transmit(&huart2, (uint8_t *)buffer, strlen(buffer), HAL_MAX_DELAY);
}


//==========================================================
//  Fonction pour configurer l'UART et lire l'amplitude et la fréquence
//==========================================================
void UART(void) {
    char buffer[10];
    print("\r\nEnter PWM amplitude (0-100): ");
    HAL_UART_Receive(&huart2, (uint8_t*)buffer, sizeof(buffer), HAL_MAX_DELAY);
    int amp = atoi(buffer); // Convertit la valeur reçue en entier

    print("\t amplitude (0-100): %d", amp);

     print("\r\nEnter frequency (1-1KHz): ");
     HAL_UART_Receive(&huart2, (uint8_t*)buffer, sizeof(buffer), HAL_MAX_DELAY);
     int freq = atoi(buffer); // Convertit la valeur reçue en entier
     print("\tEnter PWM frequence %d: ",(int)freq);
     amplitude = amp>100? 100: amp < 0 ? 0 : amp;             //
     frequence = freq>10000.0f? 10000.0f: freq < 1 ? 1 : freq;

}


//==========================================================
//   Fonction pour lire l'état du bouton B1
//==========================================================
volatile uint8_t stop = 0;
void lireB1(){
	  if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET) { // Si appuyé
	         HAL_Delay(50);
	         while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET); // Attendre le relâchement
	         boutonEtat = !boutonEtat; // Basculer l'état
	         controle++;
	         stop = !stop;
	   }
	  print("\rButton: %d   Controle = %d",boutonEtat,controle); // Afficher l'état du bouton
}


//==========================================================
//  Fonction pour configurer le signal PWM avec la fréquence et l'amplitude spécifiées
//==========================================================
void configuration_du_signal(float freq, float amplitude)
{
	  HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);           // Arrête le PWM
	  __HAL_TIM_DISABLE_DMA(&htim2, TIM_DMA_UPDATE);    // Désactive la DMA pour le TIM2
	  HAL_DMA_Abort(&hdma_tim2_up);                    // Annule la DMA en cours

	  uint32_t ARR = (uint32_t)(SYSTEM_CORE_CLOCK/ (freq * enchetillion)) - 1; // Calcul de l'ARR pour la fréquence désirée
	  __HAL_TIM_SET_AUTORELOAD(&htim2, ARR);

	  creation_du_table_sine(amplitude,ARR);      // Crée le tableau de la sinusoïde
	 //  Démarre la DMA pour le TIM2
	  HAL_DMA_Start_IT(&hdma_tim2_up, (uint32_t)sinus, (uint32_t)&TIM2->CCR1, enchetillion);
	  __HAL_TIM_ENABLE_DMA(&htim2, TIM_DMA_UPDATE);
	  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

}



//==========================================================
//   Fonction pour créer un tableau de valeurs de sinusoïde
//==========================================================
void creation_du_table_sine(float amplitud,uint32_t arr) {
	  for (int i = 0; i < enchetillion; i++)
	  {
	    float alpha = 2.0f * PI * i / enchetillion;               // Calcul de l'angle
	    float val = ((amplitud/100)*(1.0f + sinf(alpha))) * arr ;  // Calcul de la valeur de la sinusoïde
	    sinus[i] = (uint32_t)rintf(val);                        // Arrondi à l'entier le plus proche
	  }
}



//==========================================================
//
//==========================================================
long map(long x, long entre_minimal, long entre_maximal, long sortie_minimal, long sortie_maximal) {

  return (x - entre_minimal) * (sortie_maximal - sortie_minimal) / (entre_maximal - entre_minimal) + sortie_minimal;
}



//==========================================================
//   Fonction pour lire la valeur d'un potentiomètre via ADC
//==========================================================
uint16_t lecturePotetiometre(uint32_t channel) {
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = channel;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
    HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
    uint16_t valeur = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);

    return valeur;
}


//==========================================================
//   Fonction pour lire l'amplitude et la fréquence des potentiomètres
//==========================================================
void LireAmpFreq(void) {
    uint16_t amp = lecturePotetiometre(POT1);      // Lecture du potentiomètre pour l'amplitude
    uint16_t freq = lecturePotetiometre(POT2);    // Lecture du potentiomètre pour la fréquence

    int amp_float = (int)map(amp, 0, 4095, 0, 100);
    float freq_float = (float)map(freq, 0, 4095, 0, 10000);

    amplitude =  amp_float>100? 100: amp_float < 0 ? 0 : amp_float;                      // Convertit en pourcentage
    frequence = (uint16_t)(freq_float>10000.0f? 10000.0f: freq_float < 1 ? 1 : freq_float); // Convertit en Hz
    print("\rAmp: %d\tFreq: %dHz\r\n",amplitude,(int) frequence);

}


//==========================================================
//   Fonction pour lire l'amplitude et la fréquence Python
//==========================================================
void lire_commande_uart() {
	print("\r\nVous puvez envoye vos commend desome apuye deux fois pour assure que la commend est bien evoye.\r\n");
    HAL_UART_Receive(&huart2, (uint8_t*)uart_rx_buffer, sizeof(uart_rx_buffer), HAL_MAX_DELAY);
    // Exemple : message "A050F0100"
    if (uart_rx_buffer[0] == 'A') {
        int amp = 0, freq = 0;
        sscanf(uart_rx_buffer, "A%3dF%4d", &amp, &freq);

        	   amplitude = amp;                        // Convertit en pourcentage
               frequence = (uint16_t)(freq>10000.0f? 10000.0f: freq < 1 ? 1 : freq); // Convertit en Hz

        print("\r\n-> Amplitude : %d, Frequence : %d Hz\r\n",  amp, (int) frequence);
    }
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  //configuration_du_signal(frequence, amplitude);
  float amplitude_avant = amplitude;
  float frequence_avant = frequence;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	        lireB1();
	        switch (controle)
	        {
	             case 0:
	           	    lire_commande_uart();
	           		controle++;
	           		break;
	             case 1: break;
	             case 2: UART();  controle++;      break;
	             case 3: break;
	             case 4: LireAmpFreq(); break;
	             case 5: break;
	             case 6: controle = 0;
	          	  print("\r\n\nReinitialisation bien effectue \r\n\n");
	          	  break;

	        }
	        if (amplitude != amplitude_avant || frequence != frequence_avant) {
	               configuration_du_signal(frequence, amplitude);
	               amplitude_avant = amplitude;
	               frequence_avant = frequence;
	               print("\rChangement aplique avec succe  Amp: %d\tFreq: %dHz\r\n",amplitude,(int)frequence);
	               HAL_Delay(5000);
	        }
	        print("\rAmp: %d\tFreq: %dHz\r\n",amplitude,(int)frequence);

	        HAL_Delay(10);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE; // Activation scan mode
  hadc1.Init.ContinuousConvMode = ENABLE; // Lecture en continu
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 2;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  // Configuration des canaux ADC
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = 2;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}


/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 7999; // Initial value for 50Hz
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  hdma_tim2_up.Instance = DMA1_Stream1;
  hdma_tim2_up.Init.Channel = DMA_CHANNEL_3;
  hdma_tim2_up.Init.Direction = DMA_MEMORY_TO_PERIPH;
  hdma_tim2_up.Init.PeriphInc = DMA_PINC_DISABLE;
  hdma_tim2_up.Init.MemInc = DMA_MINC_ENABLE;
  hdma_tim2_up.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
  hdma_tim2_up.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
  hdma_tim2_up.Init.Mode = DMA_CIRCULAR;
  hdma_tim2_up.Init.Priority = DMA_PRIORITY_LOW;
  hdma_tim2_up.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
  if (HAL_DMA_Init(&hdma_tim2_up) != HAL_OK)
  {
    Error_Handler();
  }

  __HAL_LINKDMA(&htim2, hdma[TIM_DMA_ID_UPDATE], hdma_tim2_up);
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
void MX_DMA_Init(void)
{
  __HAL_RCC_DMA1_CLK_ENABLE();

  HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  // PA0 - Sortie PWM (TIM2 CH1)
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF1_TIM2;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  // PA1 et PA2 - Entrées ADC
  GPIO_InitStruct.Pin = GPIO_PIN_1 | GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : B1_Pin */
    GPIO_InitStruct.Pin = B1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);
}


/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
